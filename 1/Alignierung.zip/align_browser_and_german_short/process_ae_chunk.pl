#!/usr/bin/perl -w

use strict;

my $chunk = shift;

if (-e "align.out" or -e "align2.out") {
    die "FATAL: output files align.out or align2.out already exist\n";
}

my $time = time;

die unless -e "ae_chunk.e.$chunk";
die unless -e "ae_chunk.f.$chunk";

show_run("cp ae_chunk.e.$chunk e");
show_run("cp ae_chunk.f.$chunk f");

if (-e "ae_chunk.$chunk.sure") {
    show_run("cp ae_chunk.$chunk.sure align");
    show_run("cp ae_chunk.$chunk.sure ae_chunk.$chunk.sure.BACKUP_$time");
}
else {
    show_run("cp /dev/null align");
}

if (-e "ae_chunk.$chunk.possible") {
    show_run("cp ae_chunk.$chunk.possible align2");
    show_run("cp ae_chunk.$chunk.possible ae_chunk.$chunk.possible.BACKUP_$time");
}
else {
    show_run("cp /dev/null align2");
}

show_run("cp /dev/null hyp");

open(OUT, ">done.sh") or die;
print OUT "cp align.out align\n";
print OUT "cp align2.out align2\n";
print OUT "mv align.out ae_chunk.$chunk.sure\n";
print OUT "mv align2.out ae_chunk.$chunk.possible\n";
close(OUT) or die "could not close done.sh after writing\n";

print "NOW DO FOLLOWING:\n";

# java -Xms64m -Xmx512m
# The -Xms64m specifies the initial amount of RAM you want to allocate
# to the Java heap (this example is 64 MB). The -Xmx512m specifies the
# maximum amount of RAM you want to allocate. If you have 2GB of free
# RAM, you could set this number to something like 1024m.

print "% java -Xms512m -Xmx1024m TestAlign7\n";
print "% sh done.sh\n";

sub show_run {
    my $cmd = shift;
    print STDERR "$cmd\n";
    open(CMD, "$cmd 2>&1 |") or die "failed to open pipe for |$cmd|\n";
    while (<CMD>) {
	print STDERR;
    }
    close(CMD) or warn "pipe for |$cmd| non-zero on close\n";
}
